//package gameEntities.towers;
//
//public class SniperTower implements Tower
//{
//}
