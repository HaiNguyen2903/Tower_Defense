//package gameEntities.towers;
//
//public class MachineGunTower implements Tower
//{
//}
