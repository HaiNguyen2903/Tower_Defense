//package gameEntities.enemies;
//
//public class TankerEnemy extends Enemy
//{
//}
