//package gameEntities.gameTiles;
//
//public class StartPoint extends Road
//{
//}
