package player;

import gameEntities.enemies.Enemy;

import java.util.ArrayList;

public class Player
{
    protected double maxHP;
    protected double currentHP;
    protected double d;

    public Player()
    {
        maxHP = 100;
        currentHP = 100;
        d = currentHP / maxHP;
    }

    public double getCurrentHP()
    {
        return this.currentHP;
    }
    public void setCurrentHP(double currentHP)
    {
        this.currentHP = currentHP;
    }

    public double getD()
    {
        return d;
    }
    public void setD(double d)
    {
        this.d = d;
    }
}
